#include <iostream>
#include "huffman.h"
using namespace std;

int main(int argc, char *argv[])
{
	if(*argv[1] == '1')
	{
		huffman h("encodedFile.txt", "decodedFile.txt");
		h.huff_recreate_huffman_tree();
		h.huff_decoding_save();
		cout << endl;
		return 0;
	}
	else
	{
		huffman h("originalFile.txt", "encodedFile.txt");
		h.huff_create_pq();
		h.huff_create_huffman_tree();
		h.huff_calculate_huffman_codes();
		h.huff_coding_save();
		cout << endl;
		return 0;
	}
}
